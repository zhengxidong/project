<?php
namespace Admin\Controller;
use Think\Controller;
class PageController extends PublicController{
	public function adminindex(){	
		$this->display();
	}
	public function shopindex(){	
		$this->display();
	}		
}